<div class="bkground-bottom mr0">
	<div class="logo-cont">
		<img class="center-block" src="{{asset('img/logo-white.svg')}}" alt="">

		<h1 class="text-center"><b>M</b>ovimiento de <b>A</b>cción <b>S</b>ocial</h1>
	</div>
</div>