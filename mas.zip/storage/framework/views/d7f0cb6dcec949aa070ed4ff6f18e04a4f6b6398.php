<div class="bkground-bottom mr0">
	<div class="logo-cont">
		<img class="center-block" src="<?php echo e(asset('img/logo-white.svg')); ?>" alt="">

		<h1 class="text-center"><b>M</b>ovimiento de <b>A</b>cción <b>S</b>ocial</h1>
	</div>
</div><?php /**PATH C:\xampp\htdocs\GitHub\mas\resources\views/inc/bkground-bottom.blade.php ENDPATH**/ ?>